var _g_p_s_r_defs_8h =
[
    [ "GPSR_UDP_PORT", "_g_p_s_r_defs_8h.html#af0738736523dcee538988300cf9d2d7a", null ],
    [ "GPSRForwardingMode", "_g_p_s_r_defs_8h.html#af66748b574345d2f6d9dbe04509ca88b", [
      [ "GPSR_GREEDY_ROUTING", "_g_p_s_r_defs_8h.html#af66748b574345d2f6d9dbe04509ca88ba016d8c0582d020f2ab5874bc5ed59bbc", null ],
      [ "GPSR_PERIMETER_ROUTING", "_g_p_s_r_defs_8h.html#af66748b574345d2f6d9dbe04509ca88ba95761680dfe9c557e2f83d51fc6343be", null ]
    ] ],
    [ "GPSRPlanarizationMode", "_g_p_s_r_defs_8h.html#aacddfb368b32f86dfa5f4cefbc2a1385", [
      [ "GPSR_GG_PLANARIZATION", "_g_p_s_r_defs_8h.html#aacddfb368b32f86dfa5f4cefbc2a1385a7afa5f902764dc9eccd9f763e913b025", null ],
      [ "GPSR_RNG_PLANARIZATION", "_g_p_s_r_defs_8h.html#aacddfb368b32f86dfa5f4cefbc2a1385a8898f560a182ef4fb8f5f1546c91fc14", null ]
    ] ]
];