var _ethernet_application_8h =
[
    [ "EthernetApplication", "class_ethernet_application.html", "class_ethernet_application" ],
    [ "MAX_REPLY_CHUNK_SIZE", "_ethernet_application_8h.html#a4ee7696fdaea61c635c4c28e910113b9", null ]
];