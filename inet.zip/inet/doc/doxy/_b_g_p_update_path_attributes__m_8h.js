var _b_g_p_update_path_attributes__m_8h =
[
    [ "BGPUpdateAttributeFlags", "struct_b_g_p_update_attribute_flags.html", "struct_b_g_p_update_attribute_flags" ],
    [ "BGPUpdateAttributeType", "struct_b_g_p_update_attribute_type.html", "struct_b_g_p_update_attribute_type" ],
    [ "BGPUpdatePathAttributes", "class_b_g_p_update_path_attributes.html", "class_b_g_p_update_path_attributes" ],
    [ "BGPUpdatePathAttributesOrigin", "class_b_g_p_update_path_attributes_origin.html", "class_b_g_p_update_path_attributes_origin" ],
    [ "BGPUpdatePathAttributesASPath", "class_b_g_p_update_path_attributes_a_s_path.html", "class_b_g_p_update_path_attributes_a_s_path" ],
    [ "BGPUpdatePathAttributesNextHop", "class_b_g_p_update_path_attributes_next_hop.html", "class_b_g_p_update_path_attributes_next_hop" ],
    [ "BGPUpdatePathAttributesLocalPref", "class_b_g_p_update_path_attributes_local_pref.html", "class_b_g_p_update_path_attributes_local_pref" ],
    [ "BGPUpdatePathAttributesAtomicAggregate", "class_b_g_p_update_path_attributes_atomic_aggregate.html", "class_b_g_p_update_path_attributes_atomic_aggregate" ],
    [ "INET_API", "_b_g_p_update_path_attributes__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_b_g_p_update_path_attributes__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "BGPUpdateAtomicAggregateValues", "_b_g_p_update_path_attributes__m_8h.html#abb54f019f8df6c07bd67c2789ab0f78a", [
      [ "NO_SPECIFIC_ROUTE", "_b_g_p_update_path_attributes__m_8h.html#abb54f019f8df6c07bd67c2789ab0f78aa6216430b6f61e37c3a37a9641165a998", null ],
      [ "SPECIFIC_ROUTE", "_b_g_p_update_path_attributes__m_8h.html#abb54f019f8df6c07bd67c2789ab0f78aaf70d8107cf353d705ad0478d4753b6a2", null ]
    ] ],
    [ "BGPUpdateAttributeTypeCode", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41", [
      [ "ORIGIN", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41a728ec6e0f245351afc27c40f4161d4c9", null ],
      [ "AS_PATH", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41a9d650080aa2a1cf230549c85b06825c7", null ],
      [ "NEXT_HOP", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41a65c0bf6d13132f53e73e685a568c96c4", null ],
      [ "LOCAL_PREF", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41aab28bfec0eed40f6e6e309cdc9e69561", null ],
      [ "ATOMIC_AGGREGATE", "_b_g_p_update_path_attributes__m_8h.html#aa999c53e5e518e8aceb653527ab29d41a5973d610c4e9a61add04c9b8e809a88a", null ]
    ] ],
    [ "BGPUpdateOriginValues", "_b_g_p_update_path_attributes__m_8h.html#a308747ffa51e288473d3ecf62c655799", [
      [ "IGP", "_b_g_p_update_path_attributes__m_8h.html#a308747ffa51e288473d3ecf62c655799a936ac54800f7a046fae4bfbe0a8bfc61", null ],
      [ "EGP", "_b_g_p_update_path_attributes__m_8h.html#a308747ffa51e288473d3ecf62c655799a1179e8a71fb92e26ab01d0e4ebd0f8be", null ],
      [ "INCOMPLETE", "_b_g_p_update_path_attributes__m_8h.html#a308747ffa51e288473d3ecf62c655799a0a00da50814c46c6e714304c1bdd35e7", null ]
    ] ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#ab89ff64c029124b788c2cd93d58aa41e", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a2ab8f717d7afcc630062f3b9df0c504f", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a454da6a0d41597986b9edc91636105e8", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a58de8296a31443dbb6e6fdcd0f8a32ad", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a5a713b262c0737532ce8be437c479741", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a4c1e80c5e6eac6f987eb5f33a1dcbe25", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#ade7b21788da2f4afb83ec29c6679cd51", null ],
    [ "doPacking", "_b_g_p_update_path_attributes__m_8h.html#a3404ce3da9ff7f4096142ef42c7d731e", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#aa431b2f958c04f32c1990cae09cb3e73", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#a3b40a5aa7cba3c62e5fd0cd6e1d600ef", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#ac071b1fe0496daec06f024780173542b", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#a50a5b2f27ef9e8924059141cbc5c7379", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#a59df3696918b554f4c4f90f012e62e1d", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#a29e78e25e1cf8d27a86c0c44392af0c0", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#ab0f1ae64668445a4c688044ec4f63981", null ],
    [ "doUnpacking", "_b_g_p_update_path_attributes__m_8h.html#aeb01846b0b9fbb186ea7f394ff9cbc96", null ]
];