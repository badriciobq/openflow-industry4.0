var _dummy_8cc =
[
    [ "Dummy", "class_dummy.html", "class_dummy" ],
    [ "Define_Module", "_dummy_8cc.html#ab2c7870294710ac364c82d698f5ee181", null ]
];