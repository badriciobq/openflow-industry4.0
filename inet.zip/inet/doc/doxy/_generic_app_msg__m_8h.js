var _generic_app_msg__m_8h =
[
    [ "GenericAppMsg", "class_generic_app_msg.html", "class_generic_app_msg" ],
    [ "INET_API", "_generic_app_msg__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_generic_app_msg__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_generic_app_msg__m_8h.html#ab8959490fbdee27f004f244510b619b0", null ],
    [ "doUnpacking", "_generic_app_msg__m_8h.html#aed6e3d1530f966156a430e7819239b66", null ]
];