var _d_y_m_odefs_8h =
[
    [ "DYMO_NAMESPACE_BEGIN", "_d_y_m_odefs_8h.html#a1512b59230e818c2d83e26734c16be77", null ],
    [ "DYMO_NAMESPACE_END", "_d_y_m_odefs_8h.html#a6eeacffe9b71721986a41b92bdae2b0f", null ],
    [ "DYMO_UDP_PORT", "_d_y_m_odefs_8h.html#ab205f91b0ae82d2feedf8cd5418f490d", null ],
    [ "DYMOSequenceNumber", "_d_y_m_odefs_8h.html#a5405afaf21f5260a63aed0fa5b8c9c65", null ],
    [ "DYMOMetricType", "_d_y_m_odefs_8h.html#a6b5ed6853604f60531e542745a6f14ca", [
      [ "HOP_COUNT", "_d_y_m_odefs_8h.html#a6b5ed6853604f60531e542745a6f14caa315828b2bf3f6dc6d72924a208fdb2ff", null ]
    ] ],
    [ "DYMORouteState", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715db", [
      [ "ACTIVE", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715dba33cf1d8ef1d06ee698a7fabf40eb3a7f", null ],
      [ "IDLE", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715dbafd6a0e4343048b10646dd2976cc5ad18", null ],
      [ "EXPIRED", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715dbad64c9726f24e01be64f489fe57967d56", null ],
      [ "BROKEN", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715dbaeb30bf699a39ea2cb5819381461ee54d", null ],
      [ "TIMED", "_d_y_m_odefs_8h.html#a5619224240b360291f09df86351715dba4af16e797105fddaa50065d54c6a6076", null ]
    ] ]
];