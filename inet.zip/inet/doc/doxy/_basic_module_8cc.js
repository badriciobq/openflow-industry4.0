var _basic_module_8cc =
[
    [ "coreEV", "_basic_module_8cc.html#a27f667d27591f62ecf86a99a79ea8f42", null ]
];