var _b_g_p_update__m_8h =
[
    [ "BGPUpdateWithdrawnRoutes", "struct_b_g_p_update_withdrawn_routes.html", "struct_b_g_p_update_withdrawn_routes" ],
    [ "BGPUpdateNLRI", "struct_b_g_p_update_n_l_r_i.html", "struct_b_g_p_update_n_l_r_i" ],
    [ "BGPUpdatePathAttributeList", "class_b_g_p_update_path_attribute_list.html", "class_b_g_p_update_path_attribute_list" ],
    [ "BGPUpdateMessage_Base", "class_b_g_p_update_message___base.html", "class_b_g_p_update_message___base" ],
    [ "INET_API", "_b_g_p_update__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_b_g_p_update__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_b_g_p_update__m_8h.html#a175d7dc97428c67262b0a815673a5144", null ],
    [ "doPacking", "_b_g_p_update__m_8h.html#a10c53af7809637ff65d6c277da5c48dc", null ],
    [ "doPacking", "_b_g_p_update__m_8h.html#ac9aee78fa46531159bf25880a9c88f34", null ],
    [ "doUnpacking", "_b_g_p_update__m_8h.html#a500b306913f119f1dc7be6c2d664d1e8", null ],
    [ "doUnpacking", "_b_g_p_update__m_8h.html#ad3ba5ca08f4ea592c29ddb261e192b00", null ],
    [ "doUnpacking", "_b_g_p_update__m_8h.html#a3a8f039232ed9e1e8d16e8fad39a3b0e", null ],
    [ "BGP_EMPTY_UPDATE_OCTETS", "_b_g_p_update__m_8h.html#af58ab105c8561172db0a06da775498f7", null ]
];