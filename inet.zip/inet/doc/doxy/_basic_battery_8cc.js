var _basic_battery_8cc =
[
    [ "Define_Module", "_basic_battery_8cc.html#a13b262e1d880e378f08624f22e1c03c6", null ]
];