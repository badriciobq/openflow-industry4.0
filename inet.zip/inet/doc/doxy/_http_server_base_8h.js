var _http_server_base_8h =
[
    [ "HttpServerBase", "class_http_server_base.html", "class_http_server_base" ],
    [ "HtmlPageData", "struct_http_server_base_1_1_html_page_data.html", "struct_http_server_base_1_1_html_page_data" ],
    [ "MSGKIND_NEXT_MESSAGE", "_http_server_base_8h.html#ad988455eb1265f09bfc9b411718353c8", null ],
    [ "MSGKIND_SCRIPT_EVENT", "_http_server_base_8h.html#a84daaf142345857dc943d017e035f772", null ],
    [ "MSGKIND_START_SESSION", "_http_server_base_8h.html#ad815cd8dffefef3ecf9db17f2e0d1be0", null ]
];