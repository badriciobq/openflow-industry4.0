var _b_g_p_header__m_8h =
[
    [ "BGPHeader", "class_b_g_p_header.html", "class_b_g_p_header" ],
    [ "INET_API", "_b_g_p_header__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_b_g_p_header__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "BGPType", "_b_g_p_header__m_8h.html#a3475fd7f0f2886415b4f44b30355217b", [
      [ "BGP_OPEN", "_b_g_p_header__m_8h.html#a3475fd7f0f2886415b4f44b30355217ba99b99321156ab96561b88e01e2cd35be", null ],
      [ "BGP_UPDATE", "_b_g_p_header__m_8h.html#a3475fd7f0f2886415b4f44b30355217ba44f1a605f8766324aea0930f49145dca", null ],
      [ "BGP_NOTIFICATION", "_b_g_p_header__m_8h.html#a3475fd7f0f2886415b4f44b30355217ba0dab22cda53b6c958b4c63e5cb533cce", null ],
      [ "BGP_KEEPALIVE", "_b_g_p_header__m_8h.html#a3475fd7f0f2886415b4f44b30355217ba205462cc674ef6e1f97d983688ffbdc0", null ]
    ] ],
    [ "doPacking", "_b_g_p_header__m_8h.html#a56a8e1f958884c1792269783d2cf7662", null ],
    [ "doUnpacking", "_b_g_p_header__m_8h.html#ac72c3ce0a73bcd1da1de3d7bcbb7f3e6", null ],
    [ "BGP_HEADER_OCTETS", "_b_g_p_header__m_8h.html#a81b38b2a6399dd619e524cf8183b0ba3", null ]
];