var _ether_m_a_c_full_duplex_8cc =
[
    [ "Define_Module", "_ether_m_a_c_full_duplex_8cc.html#a9eea7b0d8989d6809fbf0e7422d90535", null ]
];