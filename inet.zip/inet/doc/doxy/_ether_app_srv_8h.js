var _ether_app_srv_8h =
[
    [ "EtherAppSrv", "class_ether_app_srv.html", "class_ether_app_srv" ],
    [ "MAX_REPLY_CHUNK_SIZE", "_ether_app_srv_8h.html#a4ee7696fdaea61c635c4c28e910113b9", null ]
];