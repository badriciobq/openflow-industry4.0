var _ether_m_a_c_8cc =
[
    [ "CASE", "_ether_m_a_c_8cc.html#a60cc06bef97da802b8522d258ac4fe89", null ],
    [ "Define_Module", "_ether_m_a_c_8cc.html#aaafe92cf43a371ea0bae4edbc5e23e85", null ]
];