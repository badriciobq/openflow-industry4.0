var _compat_8h =
[
    [ "EV_DEBUG", "_compat_8h.html#a287cddcb098a38db86a1f854156e8ab2", null ],
    [ "EV_DEBUG_C", "_compat_8h.html#ab920e9199eb30b77d412555401edef34", null ],
    [ "EV_DETAIL", "_compat_8h.html#a8a503e0ad7339523a69e370288c25e0b", null ],
    [ "EV_DETAIL_C", "_compat_8h.html#a98996690f390ca0f7c789ac6f803eb30", null ],
    [ "EV_ERROR", "_compat_8h.html#a27b348ffd20ee22cf301edf893debd41", null ],
    [ "EV_ERROR_C", "_compat_8h.html#a3ef558853ee8125819ce37349d4068ae", null ],
    [ "EV_FATAL", "_compat_8h.html#a21ca59ae14a670274065f4e1ed58db12", null ],
    [ "EV_FATAL_C", "_compat_8h.html#a1e63e11dd5ac14f0cc5a72e83a469676", null ],
    [ "EV_INFO", "_compat_8h.html#add5f124c5c627d3254ac1fec6eef473b", null ],
    [ "EV_INFO_C", "_compat_8h.html#a160ca5b7a760ffca374cea2b939f396c", null ],
    [ "EV_STATICCONTEXT", "_compat_8h.html#ad1ac625347054d125541b99977b568c6", null ],
    [ "EV_TRACE", "_compat_8h.html#a3e58f5026fe6c3d164f80b1e2595438e", null ],
    [ "EV_TRACE_C", "_compat_8h.html#a1b3099ed4a93eee07ffdced3cce3ed51", null ],
    [ "EV_WARN", "_compat_8h.html#a44af3daae0a3db64e9a0ac2e2ecfc4cc", null ],
    [ "EV_WARN_C", "_compat_8h.html#a4aec577e7c227c1954aa980471f97fec", null ],
    [ "EVSTREAM", "_compat_8h.html#afedfd09e9589099a8cfcc7a9a6e1ac41", null ],
    [ "Register_Abstract_Class", "_compat_8h.html#a4996ee5f60d8a90d36a71946fb202faa", null ],
    [ "check_and_cast", "_compat_8h.html#a5787efb2b2de33062f85128eb2dab921", null ],
    [ "check_and_cast", "_compat_8h.html#acfbc1067cf589eba83f5bfbe1a91337f", null ],
    [ "check_and_cast_nullable", "_compat_8h.html#a0b0a130b6f68de0c32af7a1297bb96c7", null ]
];