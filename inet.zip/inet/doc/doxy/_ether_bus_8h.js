var _ether_bus_8h =
[
    [ "EtherBus", "class_ether_bus.html", "class_ether_bus" ],
    [ "BusTap", "struct_ether_bus_1_1_bus_tap.html", "struct_ether_bus_1_1_bus_tap" ],
    [ "DOWNSTREAM", "_ether_bus_8h.html#a0fdd4161dbd1e51472cb8977d633f144", null ],
    [ "UPSTREAM", "_ether_bus_8h.html#aecc70b06b9893c001633b54e288ff29d", null ]
];