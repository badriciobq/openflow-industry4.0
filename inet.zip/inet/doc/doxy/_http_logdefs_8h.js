var _http_logdefs_8h =
[
    [ "EV_DEBUG", "_http_logdefs_8h.html#a287cddcb098a38db86a1f854156e8ab2", null ],
    [ "EV_ERROR", "_http_logdefs_8h.html#a27b348ffd20ee22cf301edf893debd41", null ],
    [ "EV_INFO", "_http_logdefs_8h.html#add5f124c5c627d3254ac1fec6eef473b", null ],
    [ "EV_SUMMARY", "_http_logdefs_8h.html#ae5603e70ab69b41f3c3f9ebf3ffe0f95", null ],
    [ "EV_WARNING", "_http_logdefs_8h.html#af1706d7077e5bad80d47a37c90ffd9dc", null ],
    [ "LL_DEBUG", "_http_logdefs_8h.html#abcaffe365dee628fcf9fc90c69d534a1", null ],
    [ "LL_INFO", "_http_logdefs_8h.html#a78288b5a41e9fb6426788b32a36b364c", null ],
    [ "LL_NONE", "_http_logdefs_8h.html#acd7c746050b9db50b0dbe103fe5c99d1", null ]
];