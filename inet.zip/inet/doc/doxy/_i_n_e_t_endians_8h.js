var _i_n_e_t_endians_8h =
[
    [ "htole16", "_i_n_e_t_endians_8h.html#a3ea73a6089f61223b225c46e2ba58a47", null ],
    [ "htole32", "_i_n_e_t_endians_8h.html#a9bea1e76e277f13ae39ac86095510bfa", null ],
    [ "le16toh", "_i_n_e_t_endians_8h.html#a684a5d26d1989cbd925e97292cc81c72", null ],
    [ "le32toh", "_i_n_e_t_endians_8h.html#ad2dfbafcefb3add65ea44e581398e90a", null ]
];