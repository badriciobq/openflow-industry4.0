var _coord_8cc =
[
    [ "dist", "_coord_8cc.html#a964f5421c0220ba2acececef201038d4", null ]
];