var _ext_interface_8cc =
[
    [ "WANT_WINSOCK2", "_ext_interface_8cc.html#a105264025fbdfc308077979bc21a5474", null ],
    [ "Define_Module", "_ext_interface_8cc.html#a4bc31a5e0460405c573d4d79f31cfc02", null ]
];