var _http_browser_base_8h =
[
    [ "HttpBrowserBase", "class_http_browser_base.html", "class_http_browser_base" ],
    [ "BrowseEvent", "struct_http_browser_base_1_1_browse_event.html", "struct_http_browser_base_1_1_browse_event" ],
    [ "MAX_URL_LENGTH", "_http_browser_base_8h.html#a3a0a3a9d3952e2b57333ed6daceb163e", null ],
    [ "MSGKIND_ACTIVITY_START", "_http_browser_base_8h.html#aa6571439be2523bf1e9c52cd069003f4", null ],
    [ "MSGKIND_NEXT_MESSAGE", "_http_browser_base_8h.html#ad988455eb1265f09bfc9b411718353c8", null ],
    [ "MSGKIND_SCRIPT_EVENT", "_http_browser_base_8h.html#a84daaf142345857dc943d017e035f772", null ],
    [ "MSGKIND_START_SESSION", "_http_browser_base_8h.html#ad815cd8dffefef3ecf9db17f2e0d1be0", null ]
];