var _i_pv6_address_8cc =
[
    [ "LINK_LOCAL_MASK", "_i_pv6_address_8cc.html#aad29318188aa722e5c58283d1c2ad14c", null ],
    [ "LINK_LOCAL_PREFIX", "_i_pv6_address_8cc.html#ab9e8317d7c73a1e4e4b498e950366565", null ],
    [ "MULTICAST_MASK", "_i_pv6_address_8cc.html#a3529bd4fe754fd51cdd382f16d9e6757", null ],
    [ "MULTICAST_PREFIX", "_i_pv6_address_8cc.html#a2e97eea4874ef7547f00f8063b77ff9f", null ],
    [ "SITE_LOCAL_MASK", "_i_pv6_address_8cc.html#afd008cb85ef7a1885c94e7bf6c2d6f67", null ],
    [ "SITE_LOCAL_PREFIX", "_i_pv6_address_8cc.html#a9b1c877783c7f52ffe09e1deaf22d50d", null ]
];