var _ext_frame__m_8h =
[
    [ "ExtFrame", "class_ext_frame.html", "class_ext_frame" ],
    [ "INET_API", "_ext_frame__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_ext_frame__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_ext_frame__m_8h.html#aab1978863fc37c2ff14b3d5c2fae6799", null ],
    [ "doUnpacking", "_ext_frame__m_8h.html#aa52956d9bf16661a8ec771383f50b0b5", null ]
];