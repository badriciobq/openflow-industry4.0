var _d_h_c_p_options_8h =
[
    [ "DHCPOption", "class_d_h_c_p_option.html", "class_d_h_c_p_option" ],
    [ "op_code", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940f", [
      [ "DHCP_MSG_TYPE", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940faac1594503316916239ff32ff67a5ff64", null ],
      [ "CLIENT_ID", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fadbccc274318f909228d315dd749f71fc", null ],
      [ "HOSTNAME", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940faa610f095750271ce06f711df89fb091b", null ],
      [ "REQUESTED_IP", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fa410cceaac02c82cda2b198aac79f4652", null ],
      [ "PARAM_LIST", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fad3063b0c170d7a504599d76e6f9fe86e", null ],
      [ "SUBNET_MASK", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fa7a2fb33aeb5abad14f57cf136c43f0ed", null ],
      [ "ROUTER", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fad5cccab5214052e4d9ba58d4e198ef92", null ],
      [ "DNS", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940facb351e08d637347c1132ba8a73f0c812", null ],
      [ "NTP_SRV", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fac5db7f24687d35b527928f3657066cef", null ],
      [ "RENEWAL_TIME", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fa540bd99421bac2bf454dc96ed0a4c629", null ],
      [ "REBIND_TIME", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940faf6807b2724d4f8653e469839b0ca6567", null ],
      [ "LEASE_TIME", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940fa50a0c59da59eb197201095e058dc1138", null ],
      [ "SERVER_ID", "_d_h_c_p_options_8h.html#aa48c0ba3c7a16f8d52b2f905b2ba940facc9d7d342c77b23067cdb9f0a900fa2a", null ]
    ] ]
];