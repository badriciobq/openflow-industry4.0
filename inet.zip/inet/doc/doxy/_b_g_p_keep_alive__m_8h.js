var _b_g_p_keep_alive__m_8h =
[
    [ "BGPKeepAliveMessage", "class_b_g_p_keep_alive_message.html", "class_b_g_p_keep_alive_message" ],
    [ "INET_API", "_b_g_p_keep_alive__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_b_g_p_keep_alive__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_b_g_p_keep_alive__m_8h.html#a17a2c5a5672651ee1919a43177c33a0b", null ],
    [ "doUnpacking", "_b_g_p_keep_alive__m_8h.html#ac2085f4d0093cd21bed321def0cccfed", null ]
];