var _i_pv4_datagram__m_8h =
[
    [ "IPv4RecordRouteOption", "class_i_pv4_record_route_option.html", "class_i_pv4_record_route_option" ],
    [ "IPv4TimestampOption", "class_i_pv4_timestamp_option.html", "class_i_pv4_timestamp_option" ],
    [ "IPv4SourceRoutingOption", "class_i_pv4_source_routing_option.html", "class_i_pv4_source_routing_option" ],
    [ "IPv4Datagram_Base", "class_i_pv4_datagram___base.html", "class_i_pv4_datagram___base" ],
    [ "INET_API", "_i_pv4_datagram__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_i_pv4_datagram__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "IPOption", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15", [
      [ "IPOPTION_END_OF_OPTIONS", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15a7dd3c5c6e686124ea2bf1c4e6d696cd8", null ],
      [ "IPOPTION_NO_OPTION", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15ab66e1534282e065015aafbfa17755640", null ],
      [ "IPOPTION_STREAM_ID", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15ae18007338e5aa690807eca360d37f357", null ],
      [ "IPOPTION_TIMESTAMP", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15abb8f3fd8d553141da085a276b4769f1d", null ],
      [ "IPOPTION_SECURITY", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15a8188c74d1f5f8fc920179c4adf504f53", null ],
      [ "IPOPTION_LOOSE_SOURCE_ROUTING", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15abfd10f7603658eaafe9919d7ea48d68f", null ],
      [ "IPOPTION_RECORD_ROUTE", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15a68e51dffde4cf43082b8c718f8e52a6b", null ],
      [ "IPOPTION_STRICT_SOURCE_ROUTING", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15a199322549c177c21482a5bfd447ec383", null ],
      [ "IPOPTION_ROUTER_ALERT", "_i_pv4_datagram__m_8h.html#aa9ab5c94a72746d79e5adbb089ceaf15af217a7592a3e3db9375b367df8f9770d", null ]
    ] ],
    [ "IPOptionClass", "_i_pv4_datagram__m_8h.html#abfa570ee9584127311c1716117ac7ed9", [
      [ "IPOPTION_CLASS_CONTROL", "_i_pv4_datagram__m_8h.html#abfa570ee9584127311c1716117ac7ed9a0b6d1423eae744b3cae4f2d2deabc254", null ],
      [ "IPOPTION_CLASS_RESERVED", "_i_pv4_datagram__m_8h.html#abfa570ee9584127311c1716117ac7ed9ae4abb4c1b9bd666808b75a86e5e771d4", null ],
      [ "IPOPTION_CLASS_DEBUGGING", "_i_pv4_datagram__m_8h.html#abfa570ee9584127311c1716117ac7ed9ada98754823d9bee3a2e8c716332198f3", null ],
      [ "IPOPTION_CLASS_RESERVED2", "_i_pv4_datagram__m_8h.html#abfa570ee9584127311c1716117ac7ed9a51fd8bfd9f9fdaddcf05d72487da5611", null ]
    ] ],
    [ "TimestampFlag", "_i_pv4_datagram__m_8h.html#acc1267dc708aa8efc86ad0572d575e33", [
      [ "IP_TIMESTAMP_TIMESTAMP_ONLY", "_i_pv4_datagram__m_8h.html#acc1267dc708aa8efc86ad0572d575e33ace7d6d716d77e1fe18134c8b38c844d6", null ],
      [ "IP_TIMESTAMP_WITH_ADDRESS", "_i_pv4_datagram__m_8h.html#acc1267dc708aa8efc86ad0572d575e33a83d8173330dc86d2a88b7ad0e043ac72", null ],
      [ "IP_TIMESTAMP_SENDER_INIT_ADDRESS", "_i_pv4_datagram__m_8h.html#acc1267dc708aa8efc86ad0572d575e33a2e7d23d4754323e53f5ecdfc037dc233", null ]
    ] ],
    [ "doPacking", "_i_pv4_datagram__m_8h.html#ae826241bb6ececd48db69f8cff9c2f89", null ],
    [ "doPacking", "_i_pv4_datagram__m_8h.html#a94cb3c03ad433dba211fbd0e6c3dad10", null ],
    [ "doPacking", "_i_pv4_datagram__m_8h.html#a1097496b0821e277f1060982bf5dd59c", null ],
    [ "doUnpacking", "_i_pv4_datagram__m_8h.html#a1b330acf757f343aea3bfe61685c8139", null ],
    [ "doUnpacking", "_i_pv4_datagram__m_8h.html#a87cb8e7c65537c2bed090ad3ea6e6f11", null ],
    [ "doUnpacking", "_i_pv4_datagram__m_8h.html#afd647e153cc2688d8d52f37f7e6c9182", null ],
    [ "IP_HEADER_BYTES", "_i_pv4_datagram__m_8h.html#a55f0b603ebc964b1dc679f0d6741a9d8", null ],
    [ "IP_MAX_HEADER_BYTES", "_i_pv4_datagram__m_8h.html#ac849bbae039e87714709568464b80331", null ],
    [ "IPOPTION_CLASS_MASK", "_i_pv4_datagram__m_8h.html#afd468973e36ba15aafbf978f36bc01eb", null ],
    [ "IPOPTION_COPY_MASK", "_i_pv4_datagram__m_8h.html#a0571ac04dba07e90cdc4322561d592ae", null ],
    [ "IPOPTION_NUMBER_MASK", "_i_pv4_datagram__m_8h.html#a67fa4e5dbe16326c8dcf7daca1ca65d8", null ],
    [ "MAX_IPADDR_OPTION_ENTRIES", "_i_pv4_datagram__m_8h.html#a45953099e6b180590191a1b62712b2a2", null ],
    [ "MAX_TIMESTAMP_OPTION_ENTRIES", "_i_pv4_datagram__m_8h.html#aa63fb93171345e2644c58c1d3922788f", null ]
];