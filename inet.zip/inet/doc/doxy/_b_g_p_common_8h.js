var _b_g_p_common_8h =
[
    [ "SessionInfo", "struct_b_g_p_1_1_session_info.html", "struct_b_g_p_1_1_session_info" ],
    [ "ASID", "_b_g_p_common_8h.html#a8c7e4366444a5b3700492f842841d110", null ],
    [ "NextHop", "_b_g_p_common_8h.html#af008460b49e37bb4d322bd4614d7ce70", null ],
    [ "SessionID", "_b_g_p_common_8h.html#af3cae0ebd714e2612da44bf30455e675", null ],
    [ "type", "_b_g_p_common_8h.html#a27250f376c8b2d9a3a0d243bba9c9145", [
      [ "IGP", "_b_g_p_common_8h.html#a27250f376c8b2d9a3a0d243bba9c9145ac46ec923c65722d3a575efcbc8281dea", null ],
      [ "EGP", "_b_g_p_common_8h.html#a27250f376c8b2d9a3a0d243bba9c9145a5a0c9f9597d1b3cb5899d2ac2b7602d8", null ],
      [ "Incomplete", "_b_g_p_common_8h.html#a27250f376c8b2d9a3a0d243bba9c9145a0bbf74f7f4bedb4e3438a0d01520402f", null ]
    ] ],
    [ "AS_SEQUENCE", "_b_g_p_common_8h.html#a54e98360c5edb14f3b2453afb4a2a9f3", null ],
    [ "AS_SET", "_b_g_p_common_8h.html#a1cb8c40637fc5339aa2be0eca7dbe030", null ],
    [ "ASLOOP_DETECTED", "_b_g_p_common_8h.html#ac355bc03fbf9437d8066ed8ffa13cc88", null ],
    [ "ASLOOP_NO_DETECTED", "_b_g_p_common_8h.html#a068f1eb3f3ab9984d797d806e856de62", null ],
    [ "CONNECT_RETRY_KIND", "_b_g_p_common_8h.html#a32c23815bf744093ab3b8f58eb20e838", null ],
    [ "DEFAULT_COST", "_b_g_p_common_8h.html#a7ed5fe22d7e1baf1173192bf24ee3f2b", null ],
    [ "HOLD_TIME_KIND", "_b_g_p_common_8h.html#a317be383e737a8f3491800c9c2e2d934", null ],
    [ "KEEP_ALIVE_KIND", "_b_g_p_common_8h.html#af9bb88fd8c76a4385aacf1d6ffcac6cf", null ],
    [ "NB_SESSION_MAX", "_b_g_p_common_8h.html#a4a47a21859ed6879ce12947864fab30a", null ],
    [ "NB_STATS", "_b_g_p_common_8h.html#a1b9cf7bdb62bd2a8a922cb8907940a04", null ],
    [ "NB_TIMERS", "_b_g_p_common_8h.html#a9765062bf1fe0b2e3ab4b6585be5756f", null ],
    [ "NEW_ROUTE_ADDED", "_b_g_p_common_8h.html#a77f9dabd73d66718ad18d5100d3c1a01", null ],
    [ "NEW_SESSION_ESTABLISHED", "_b_g_p_common_8h.html#a71b84f51f5845f0b1a910885079617f5", null ],
    [ "ROUTE_DESTINATION_CHANGED", "_b_g_p_common_8h.html#a3cd8cbbd2747411c6d71e89e2fe09f1b", null ],
    [ "START_EVENT_KIND", "_b_g_p_common_8h.html#a0d2520540f3b7c216538458f594253d6", null ],
    [ "TCP_PORT", "_b_g_p_common_8h.html#a38d6ca07bed826ebb483b68a709775af", null ]
];