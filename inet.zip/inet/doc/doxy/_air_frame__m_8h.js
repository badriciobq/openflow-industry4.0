var _air_frame__m_8h =
[
    [ "AirFrame", "class_air_frame.html", "class_air_frame" ],
    [ "INET_API", "_air_frame__m_8h.html#ad4fa1dc2a221d8f0c1c417d4b993c51a", null ],
    [ "MSGC_VERSION", "_air_frame__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_air_frame__m_8h.html#a60d0647cb956093d74affad0c7fa5b0d", null ],
    [ "doUnpacking", "_air_frame__m_8h.html#a94392181cddff429b5cae665ff96b9e7", null ]
];